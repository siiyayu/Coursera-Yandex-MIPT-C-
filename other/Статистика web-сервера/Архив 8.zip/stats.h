#pragma once

#include "http_request.h"

#include <string_view>
#include <map>
#include <set>
using namespace std;

class Stats {
public:
    void AddMethod(string_view method);
    void AddUri(string_view uri);
    const map<string_view, int>& GetMethodStats() const;
    const map<string_view, int>& GetUriStats() const;

private:
    map<string_view, int> method_stats = {{"DELETE", 0}, {"GET", 0}, {"POST", 0}, {"PUT", 0}, {"UNKNOWN", 0}};
    map<string_view, int> uri_stats = {{"/", 0}, {"/basket", 0}, {"/help", 0}, {"/order", 0}, {"/product", 0}, {"unknown", 0}};
    set<string_view> methods = {"POST", "GET", "DELETE", "PUT"};
    set<string_view> uries = {"/", "/order", "/product", "/basket", "/help"};

    bool Check(set<string_view> check_list, string_view to_check);
};


