#include "stats.h"
#include <string>
#include <sstream>

void Stats::AddMethod(string_view method) {
    if (Check(methods, method)) {
        method_stats[method]++;
    } else {
        method_stats["UNKNOWN"]++;
    }
}
void Stats::AddUri(string_view uri) {
    if (Check(uries, uri)) {
        uri_stats[uri]++;
    } else {
        uri_stats["unknown"]++;
    }
}
const map<string_view, int>& Stats::GetMethodStats() const {
    return method_stats;
}
const map<string_view, int>& Stats::GetUriStats() const {
    return uri_stats;
}
bool Stats::Check(set<string_view> check_list, string_view to_check) {
    if (check_list.count(to_check) == 0) {
        return false;
    } else {
        return true;
    }
}

HttpRequest ParseRequest(string_view line) {
//    auto pos = line.find_first_of(" ", 0);
//    string_view method = line.substr(0, pos - 1);
//    line.remove_prefix(pos + 1);
//    pos = line.find_first_of(" ", 0);
//    string_view ori = line.substr(0, pos - 1);
//    //line.remove_prefix(pos + 2);
//    string_view protocol = "HTTP/1.1";
    string s(line);
    stringstream ss(s);
    while (ss.peek() == ' ') {
        ss.ignore(1);
    }
    static string method, ori, protocol;
    getline(ss, method, ' ');
    getline(ss, ori, ' ');
    getline(ss, protocol);
    HttpRequest result = {method, ori, protocol};
    return result;
}